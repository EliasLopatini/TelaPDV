package com.example.trabpaulinho.modelo;

public class Produto {

    private String codigo;
    private String descricao;
    private double valorUn;

    public Produto() {
    }

    public Produto(String codigo, String descricao, double valorUn) {
        this.codigo = codigo;
        this.descricao = descricao;
        this.valorUn = valorUn;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public double getValorUn() {
        return valorUn;
    }

    public void setValorUn(double valorUn) {
        this.valorUn = valorUn;
    }
}
